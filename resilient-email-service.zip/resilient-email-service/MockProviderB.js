module.exports = {
  send: (emailData) => {
    console.log("ProviderB sending:", emailData);
    return new Promise((resolve, reject) => {
      if (Math.random() < 0.8) resolve("ProviderB sent");
      else reject(new Error("ProviderB failed"));
    });
  }
};
