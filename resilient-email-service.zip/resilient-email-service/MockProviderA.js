module.exports = {
  send: (emailData) => {
    console.log("ProviderA sending:", emailData);
    return new Promise((resolve, reject) => {
      if (Math.random() < 0.8) resolve("ProviderA sent");
      else reject(new Error("ProviderA failed"));
    });
  }
};
