const EmailService = require('../EmailService');
const ProviderA = require('../MockProviderA');
const ProviderB = require('../MockProviderB');

describe('EmailService', () => {
  const emailService = new EmailService(ProviderA, ProviderB);

  test('should send email successfully', async () => {
    const res = await emailService.sendEmail('email-1', {
      to: 'a@test.com',
      subject: 'Hello',
      body: 'Test message'
    });
    console.log("Test result:", res.status);
    expect(['sent', 'queued', 'failed']).toContain(res.status);
  });

  test('should not send duplicate email', async () => {
    await emailService.sendEmail('email-2', {
      to: 'a@test.com',
      subject: 'Hi again',
      body: 'Hello again'
    });
    const res2 = await emailService.sendEmail('email-2', {
      to: 'a@test.com',
      subject: 'Hi again',
      body: 'Hello again'
    });
    console.log("Test result (duplicate):", res2.status);
    expect(['sent', 'queued', 'failed']).toContain(res2.status);
  });

  test('should track status', () => {
    const status = emailService.getStatus('email-1');
    console.log("Tracked status:", status);
    expect(['sent', 'queued', 'failed']).toContain(status);
  });
});
