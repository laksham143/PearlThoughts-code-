const StatusTracker = require('./StatusTracker');

class EmailService {
  constructor(primaryProvider, secondaryProvider) {
    this.primaryProvider = primaryProvider;
    this.secondaryProvider = secondaryProvider;
    this.statusTracker = new StatusTracker();
    this.sentEmailIds = new Set(); // For idempotency
    this.rateLimit = {
      maxEmailsPerMinute: 5,
      timestamps: []
    };
  }

  async sendEmail(emailId, emailData) {
    if (this.statusTracker.getStatus(emailId)) {
      console.log(`Duplicate emailId detected: ${emailId}`);
      return { status: this.statusTracker.getStatus(emailId) };
    }

    const now = Date.now();
    this.rateLimit.timestamps = this.rateLimit.timestamps.filter(ts => now - ts < 60000);
    if (this.rateLimit.timestamps.length >= this.rateLimit.maxEmailsPerMinute) {
      console.log(`Rate limit exceeded for emailId: ${emailId}`);
      this.statusTracker.setStatus(emailId, 'failed');
      return { status: 'failed' };
    }

    this.rateLimit.timestamps.push(now);

    let success = false;
    let attempt = 0;
    const maxRetries = 3;

    while (attempt < maxRetries) {
      try {
        await this.primaryProvider.send(emailData);
        this.statusTracker.setStatus(emailId, 'sent');
        success = true;
        break;
      } catch (err) {
        console.log(`Primary provider failed on attempt ${attempt + 1}: ${err.message}`);
        await this.exponentialBackoff(attempt);
        attempt++;
      }
    }

    if (!success) {
      attempt = 0;
      while (attempt < maxRetries) {
        try {
          await this.secondaryProvider.send(emailData);
          this.statusTracker.setStatus(emailId, 'queued');
          success = true;
          break;
        } catch (err) {
          console.log(`Secondary provider failed on attempt ${attempt + 1}: ${err.message}`);
          await this.exponentialBackoff(attempt);
          attempt++;
        }
      }
    }

    if (!success) {
      this.statusTracker.setStatus(emailId, 'failed');
    }

    return { status: this.statusTracker.getStatus(emailId) };
  }

  getStatus(emailId) {
    return this.statusTracker.getStatus(emailId);
  }

  async exponentialBackoff(attempt) {
    const delay = Math.pow(2, attempt) * 100;
    return new Promise(resolve => setTimeout(resolve, delay));
  }
}

module.exports = EmailService;
