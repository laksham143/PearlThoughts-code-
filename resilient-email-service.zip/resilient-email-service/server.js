const express = require('express');
const bodyParser = require('body-parser');
const EmailService = require('./EmailService'); // Adjust path if needed

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.json());

const emailService = new EmailService();

app.post('/api/send', async (req, res) => {
  const { emailId, to, subject, body } = req.body;

  if (!emailId || !to || !subject || !body) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const result = await emailService.sendEmail(emailId, { to, subject, body });
  res.json(result);
});

app.get('/', (req, res) => {
  res.send('Resilient Email API is running!');
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
