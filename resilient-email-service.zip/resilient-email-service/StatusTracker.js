class StatusTracker {
  constructor() {
    this.statusMap = new Map();
  }

  setStatus(emailId, status) {
    this.statusMap.set(emailId, status);
  }

  getStatus(emailId) {
    return this.statusMap.get(emailId);
  }
}

module.exports = StatusTracker;
